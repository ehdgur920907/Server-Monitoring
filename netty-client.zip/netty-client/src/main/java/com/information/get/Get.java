package com.information.get;

public interface Get {
	public Object execute();
}
